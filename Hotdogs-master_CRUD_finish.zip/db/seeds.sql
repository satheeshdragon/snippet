
INSERT INTO hotdogs (hotdog_name, devoured) 
VALUES ("JohnDog", 0);
INSERT INTO hotdogs (hotdog_name, devoured) 
VALUES ("DanielDog", 0);
INSERT INTO hotdogs (hotdog_name, devoured) 
VALUES ("JasonDog", 0);
INSERT INTO hotdogs (hotdog_name, devoured) 
VALUES ("AndyDog", 1);
INSERT INTO hotdogs (hotdog_name, devoured) 
VALUES ("SamDog", 1);