// Import the ORM to create functions that will interact with the database.
// var orm = require("../config/orm.js");
// require("../config/connection.js");

    var firebase = require("firebase-admin");

var serviceAccount = require("../config/my-firebase-node.json");

firebase.initializeApp({
  credential: firebase.credential.cert(serviceAccount),
  databaseURL: "https://my-firebase-node-nov.firebaseio.com"
});

var db = firebase.firestore();


var hotdog = {
  all: function(cb) {
    // orm.all("hotdogs", function(res) {
    //   cb(res);
    // });


   let user_data = [];
  
   let citiesRef = db.collection('users');
   let allCities = citiesRef.get()
  .then(snapshot => {
    snapshot.forEach(doc => {
      user_data.push(doc.data());
      // console.log(doc.id, '=>', doc.data());
    });

    cb(user_data);   
  })
  .catch(err => {
    console.log('Error getting documents', err);
  });

  // console.log(user_data);


  },
  // The variables cols and vals are arrays.
  create: function(cols, vals, cb) {
    // orm.create("hotdogs", cols, vals, function(res) {
    //   cb(res);
    // });
    let data = {
  last: 'Anu',
  first: 'daaa',
  born: '123445'
};

// Add a new document in collection "cities" with ID 'LA'
let setDoc = db.collection('users').doc().set(data);

// cb(1);


  },
  update: function(objColVals, condition, cb) {
    orm.update("hotdogs", objColVals, condition, function(res) {
      cb(res);
    });
  },
  delete: function(condition, cb) {
    orm.delete("hotdogs", condition, function(res) {
      cb(res);
    });
  }
};

// Export the database functions for the controller (hotdogsController.js).
module.exports = hotdog;
